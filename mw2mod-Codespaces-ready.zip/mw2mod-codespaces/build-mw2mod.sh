#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
chmod +x ./gradlew
./gradlew clean build
printf '\nBUILD COMPLETE\nJAR: %s\n' "$(find build/libs -maxdepth 1 -type f -name 'mw2mod-1.0.0.jar' -print -quit)"
