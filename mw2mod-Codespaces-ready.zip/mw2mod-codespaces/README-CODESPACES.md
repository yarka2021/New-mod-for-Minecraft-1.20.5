# MW2Mod — GitHub Codespaces

Minecraft **1.20.5 / Fabric**, Java **21**.

## Build

Open this folder as the Codespace root and run exactly:

```bash
./build-mw2mod.sh
```

Or:

```bash
./gradlew build
```

The finished mod is:

```text
build/libs/mw2mod-1.0.0.jar
```

If GitHub Codespaces reports `./gradlew: No such file or directory`, you are almost certainly in the wrong directory. Run:

```bash
cd mw2mod-Codespaces-ready
ls -la
```

You must see `gradlew` in the listing.
