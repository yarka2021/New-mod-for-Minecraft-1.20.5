# Modern Warfare Mod (Fabric 1.20.5)

Guns, knives, grenades and a Call of Duty style HUD for Minecraft Java 1.20.5.

## Requirements (to play)
- Minecraft Java **1.20.5** (works on 1.20.6 too)
- Fabric Loader 0.15.10+
- Fabric API 0.97.x for 1.20.5
- Java 21

## Build the .jar
**Option A, GitHub (no setup):** create a repo, upload this whole folder (keep the `.github` folder),
open the **Actions** tab, run **build**, then download `mw2mod-jar` from the finished run.

**Option B, own PC:** install JDK 21 + Gradle 8.7, run `gradle build`.
The mod is `build/libs/mw2mod-1.0.0.jar` (not the `-sources` one). Put it in `.minecraft/mods`.

## Controls
- Right click: shoot / throw grenade (hold for automatic fire)
- **R**: reload (also reloads automatically when you pull the trigger on an empty magazine)
- **Z** (hold): aim down sights. Rebind in Options > Controls > Modern Warfare
- Creative tab: **Modern Warfare**

## Content
Guns: AK-47, M4A1, Pistol, Revolver, Sniper, Shotgun, SMG, LMG, Grenade Launcher
Knives: Combat Knife, Karambit, Machete (extra damage from behind)
Grenades: Frag, Flashbang, Smoke, Incendiary
Ammo: crafted (gunpowder + metal) and dropped by hostile mobs killed by a player.
HUD: minimap (top-left), compass + ammo counter + grenades (bottom-right), dynamic crosshair, sniper scope.
Item textures are generated 2D icons; guns are flat sprites, not 3D models.
