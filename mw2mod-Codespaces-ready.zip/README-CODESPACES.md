# MW2Mod — Minecraft 1.20.5 Fabric

## GitHub Codespaces

Open this folder in GitHub Codespaces, then run exactly:

```bash
./gradlew build
```

The mod JAR will be created in:

`build/libs/mw2mod-1.0.0.jar`

Java 21 is required. The included `gradlew` automatically downloads Gradle 8.8 on first run, so Gradle does not need to be installed manually.

If you prefer a clean rebuild:

```bash
./gradlew clean build
```
