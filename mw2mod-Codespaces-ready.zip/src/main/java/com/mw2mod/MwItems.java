package com.mw2mod;

import com.mw2mod.entity.GrenadeEntity;
import com.mw2mod.item.GrenadeItem;
import com.mw2mod.item.GunItem;
import com.mw2mod.item.GunStats;
import com.mw2mod.item.KnifeItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public final class MwItems {
    private static final List<Item> ALL = new ArrayList<>();

    // ---- ammo
    public static final Item PISTOL_AMMO = item("pistol_ammo", new Item(new Item.Settings()));
    public static final Item MAGNUM_AMMO = item("magnum_ammo", new Item(new Item.Settings()));
    public static final Item RIFLE_AMMO = item("rifle_ammo", new Item(new Item.Settings()));
    public static final Item SNIPER_AMMO = item("sniper_ammo", new Item(new Item.Settings()));
    public static final Item SHOTGUN_SHELL = item("shotgun_shell", new Item(new Item.Settings()));
    public static final Item GRENADE_40MM = item("grenade_40mm", new Item(new Item.Settings()));

    // ---- firearms
    public static final GunItem AK47 = gun("ak47", new GunStats()
            .damage(5f).rounds(2).magazine(30).reloadTicks(50).spread(2.0f).range(80).recoil(1.1f).zoom(1.4f), RIFLE_AMMO);
    public static final GunItem M4A1 = gun("m4a1", new GunStats()
            .damage(4f).rounds(2).magazine(30).reloadTicks(45).spread(1.4f).range(90).recoil(0.8f).zoom(1.4f), RIFLE_AMMO);
    public static final GunItem PISTOL = gun("pistol", new GunStats()
            .damage(4.5f).cooldown(5).magazine(15).reloadTicks(35).spread(1.2f).range(60).recoil(1.0f).zoom(1.1f), PISTOL_AMMO);
    public static final GunItem REVOLVER = gun("revolver", new GunStats()
            .damage(10f).cooldown(14).magazine(6).reloadTicks(60).spread(0.6f).range(80).recoil(3.0f).zoom(1.15f).loud(), MAGNUM_AMMO);
    public static final GunItem SNIPER = gun("sniper", new GunStats()
            .damage(20f).cooldown(30).magazine(5).reloadTicks(70).spread(0.3f).range(200).recoil(4.0f).zoom(4.0f)
            .headshot(2.0f).scoped().loud(), SNIPER_AMMO);
    public static final GunItem SHOTGUN = gun("shotgun", new GunStats()
            .damage(2.5f).pellets(8).cooldown(18).magazine(6).reloadTicks(60).spread(6.0f).range(25).recoil(4.0f)
            .zoom(1.1f).headshot(1.2f).loud(), SHOTGUN_SHELL);
    public static final GunItem SMG = gun("smg", new GunStats()
            .damage(3f).rounds(2).magazine(32).reloadTicks(40).spread(2.5f).range(50).recoil(0.6f).zoom(1.15f), PISTOL_AMMO);
    public static final GunItem LMG = gun("lmg", new GunStats()
            .damage(4.5f).rounds(2).magazine(100).reloadTicks(120).spread(3.0f).range(90).recoil(1.0f).zoom(1.2f), RIFLE_AMMO);
    public static final GunItem GRENADE_LAUNCHER = gun("grenade_launcher", new GunStats()
            .cooldown(25).magazine(1).reloadTicks(50).recoil(3.0f).zoom(1.3f).launcher().loud(), GRENADE_40MM);

    // ---- knives
    public static final KnifeItem COMBAT_KNIFE = item("combat_knife", new KnifeItem(ToolMaterials.IRON,
            new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(ToolMaterials.IRON, 1, -1.0f)), 8f));
    public static final KnifeItem KARAMBIT = item("karambit", new KnifeItem(ToolMaterials.IRON,
            new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(ToolMaterials.IRON, 0, -0.5f)), 7f));
    public static final KnifeItem MACHETE = item("machete", new KnifeItem(ToolMaterials.IRON,
            new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(ToolMaterials.IRON, 3, -2.6f)), 10f));

    // ---- grenades
    public static final Item FRAG_GRENADE = item("frag_grenade",
            new GrenadeItem(new Item.Settings().maxCount(16), GrenadeEntity.Kind.FRAG, 40));
    public static final Item FLASHBANG = item("flashbang",
            new GrenadeItem(new Item.Settings().maxCount(16), GrenadeEntity.Kind.FLASH, 30));
    public static final Item SMOKE_GRENADE = item("smoke_grenade",
            new GrenadeItem(new Item.Settings().maxCount(16), GrenadeEntity.Kind.SMOKE, 30));
    public static final Item INCENDIARY_GRENADE = item("incendiary_grenade",
            new GrenadeItem(new Item.Settings().maxCount(16), GrenadeEntity.Kind.INCENDIARY, 40));

    private static GunItem gun(String id, GunStats stats, Item ammo) {
        return item(id, new GunItem(new Item.Settings().maxCount(1).component(MwComponents.AMMO, stats.magazine), stats, ammo));
    }

    private static <T extends Item> T item(String id, T item) {
        ALL.add(item);
        return Registry.register(Registries.ITEM, Mw2Mod.id(id), item);
    }

    public static void init() {
        Registry.register(Registries.ITEM_GROUP, Mw2Mod.id("main"), FabricItemGroup.builder()
                .icon(() -> new ItemStack(AK47))
                .displayName(Text.translatable("itemGroup.mw2mod.main"))
                .entries((context, entries) -> {
                    for (Item i : ALL) entries.add(i);
                })
                .build());
    }

    private MwItems() {
    }
}
