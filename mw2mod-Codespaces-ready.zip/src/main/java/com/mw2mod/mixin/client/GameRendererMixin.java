package com.mw2mod.mixin.client;

import com.mw2mod.client.ClientState;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Narrows the field of view while aiming down sights. */
@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getFov(Lnet/minecraft/client/render/Camera;FZ)D", at = @At("RETURN"), cancellable = true, require = 0)
    private void mw2mod$zoom(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        if (!changingFov) return; // do not zoom the hand/gun model
        float f = ClientState.zoomFactor(tickDelta);
        if (f > 1.001f) {
            cir.setReturnValue(cir.getReturnValue() / f);
        }
    }
}
