package com.mw2mod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

public class Mw2Mod implements ModInitializer {
    public static final String MOD_ID = "mw2mod";

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        MwComponents.init();
        MwItems.init();
        MwEntities.init();
        MwNetworking.init();
        MwDrops.init();
    }
}
