package com.mw2mod.client;

import com.mw2mod.item.GunItem;
import net.minecraft.util.math.MathHelper;

/** Small bag of client-only state shared between the tick handler, HUD and mixins. */
public final class ClientState {
    public static GunItem gun;
    public static boolean holdingGun;
    public static boolean aiming;

    public static float zoomPrev;
    public static float zoomCur;
    public static float zoomMax = 1.0f;

    public static float kick; // crosshair expansion after a shot (1 -> 0)

    public static GunItem lastGun;
    public static int lastAmmo = -1;
    public static int lastSlot = -1;

    public static float zoomFactor(float tickDelta) {
        float t = MathHelper.lerp(tickDelta, zoomPrev, zoomCur);
        return 1.0f + (zoomMax - 1.0f) * t;
    }

    public static void reset() {
        gun = null;
        holdingGun = false;
        aiming = false;
        zoomPrev = zoomCur = 0f;
        kick = 0f;
        lastGun = null;
        lastAmmo = -1;
        lastSlot = -1;
    }

    private ClientState() {
    }
}
