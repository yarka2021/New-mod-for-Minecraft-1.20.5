package com.mw2mod.client;

import com.mw2mod.MwComponents;
import com.mw2mod.MwEntities;
import com.mw2mod.item.GunItem;
import com.mw2mod.net.ReloadPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public class Mw2ModClient implements ClientModInitializer {
    public static KeyBinding reloadKey;
    public static KeyBinding aimKey;

    @Override
    public void onInitializeClient() {
        reloadKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mw2mod.reload", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.mw2mod"));
        aimKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mw2mod.aim", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, "category.mw2mod"));

        EntityRendererRegistry.register(MwEntities.GRENADE, FlyingItemEntityRenderer::new);
        ClientTickEvents.END_CLIENT_TICK.register(Mw2ModClient::tick);
        HudRenderCallback.EVENT.register(GunHud::render);
    }

    private static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            ClientState.reset();
            return;
        }

        ItemStack held = p.getMainHandStack();
        GunItem gun = held.getItem() instanceof GunItem g ? g : null;
        ClientState.gun = gun;
        ClientState.holdingGun = gun != null;

        // R = reload
        while (reloadKey.wasPressed()) {
            if (gun != null) ClientPlayNetworking.send(new ReloadPayload());
        }

        // hold Z = aim down sights
        ClientState.aiming = gun != null && aimKey.isPressed() && mc.currentScreen == null;
        if (gun != null) ClientState.zoomMax = gun.stats.zoom;
        ClientState.zoomPrev = ClientState.zoomCur;
        float target = ClientState.aiming ? 1.0f : 0.0f;
        ClientState.zoomCur += (target - ClientState.zoomCur) * 0.45f;
        if (Math.abs(target - ClientState.zoomCur) < 0.01f) ClientState.zoomCur = target;

        // recoil: the server lowers the magazine counter when we shoot, we kick the camera up
        int ammo = gun != null ? held.getOrDefault(MwComponents.AMMO, 0) : -1;
        int slot = p.getInventory().selectedSlot;
        if (gun != null && gun == ClientState.lastGun && slot == ClientState.lastSlot
                && ammo >= 0 && ClientState.lastAmmo > ammo) {
            int fired = Math.min(ClientState.lastAmmo - ammo, 3);
            float kick = gun.stats.recoil * fired * (ClientState.aiming ? 0.6f : 1.0f);
            p.setPitch(MathHelper.clamp(p.getPitch() - kick, -90f, 90f));
            p.setYaw(p.getYaw() + (p.getRandom().nextFloat() - 0.5f) * kick * 0.5f);
            ClientState.kick = 1.0f;
        }
        ClientState.lastGun = gun;
        ClientState.lastAmmo = ammo;
        ClientState.lastSlot = slot;
        ClientState.kick = Math.max(0f, ClientState.kick - 0.1f);
    }
}
