package com.mw2mod.client;

import com.mw2mod.MwComponents;
import com.mw2mod.Mw2Mod;
import com.mw2mod.MwItems;
import com.mw2mod.item.GunItem;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.block.MapColor;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.world.Heightmap;

/** Call of Duty style HUD: minimap, compass, ammo counter, grenades, crosshair, sniper scope. */
public final class GunHud {
    private static final int MAP_PIXELS = 64;   // blocks shown (64 x 64)
    private static final int MAP_SIZE = 80;     // on-screen size in GUI pixels
    private static final Identifier MAP_ID = Mw2Mod.id("dynamic_minimap");
    private static NativeImageBackedTexture mapTexture;
    private static long lastMapUpdate = -100;

    private static final String[] DIRS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    public static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.options.hudHidden) return;

        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        ItemStack held = player.getMainHandStack();

        if (held.getItem() instanceof GunItem gun) {
            drawScope(ctx, gun, w, h);
        }

        drawMinimap(ctx, mc, tr, player, 8, 8);
        drawCompass(ctx, tr, player, w, h);
        drawGrenades(ctx, tr, player, w, h);

        if (held.getItem() instanceof GunItem gun) {
            drawCrosshair(ctx, mc, gun, w, h);
            drawAmmo(ctx, mc, tr, player, held, gun, w, h);
        }
    }

    // ------------------------------------------------------------------ minimap

    private static void drawMinimap(DrawContext ctx, MinecraftClient mc, TextRenderer tr, ClientPlayerEntity player, int x, int y) {
        if (mapTexture == null) {
            mapTexture = new NativeImageBackedTexture(MAP_PIXELS, MAP_PIXELS, false);
            mc.getTextureManager().registerTexture(MAP_ID, mapTexture);
        }
        long now = mc.world.getTime();
        if (now - lastMapUpdate >= 5 || now < lastMapUpdate) {
            updateMap(mc.world, player);
            lastMapUpdate = now;
        }

        ctx.fill(x - 2, y - 2, x + MAP_SIZE + 2, y + MAP_SIZE + 2, 0xFF1E1E1E);
        ctx.drawTexture(MAP_ID, x, y, MAP_SIZE, MAP_SIZE, 0f, 0f, MAP_PIXELS, MAP_PIXELS, MAP_PIXELS, MAP_PIXELS);

        // player arrow (map is north-up, arrow shows where you look)
        float bearing = player.getYaw() + 180f;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x + MAP_SIZE / 2f, y + MAP_SIZE / 2f, 0f);
        ctx.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotationDegrees(bearing));
        for (int i = 0; i < 5; i++) {
            ctx.fill(-i, -4 + i, i + 1, -3 + i, 0xFFFFD34D);
        }
        ctx.getMatrices().pop();

        ctx.drawText(tr, "N", x + MAP_SIZE / 2 - 2, y + 2, 0xFFFFFFFF, true);
    }

    private static void updateMap(ClientWorld world, ClientPlayerEntity player) {
        NativeImage img = mapTexture.getImage();
        if (img == null) return;
        BlockPos center = player.getBlockPos();
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int dz = 0; dz < MAP_PIXELS; dz++) {
            for (int dx = 0; dx < MAP_PIXELS; dx++) {
                int x = center.getX() - MAP_PIXELS / 2 + dx;
                int z = center.getZ() - MAP_PIXELS / 2 + dz;
                int y = world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
                pos.set(x, y, z);
                BlockState state = world.getBlockState(pos);
                int abgr;
                if (state.isAir()) {
                    abgr = 0xFF101010;
                } else {
                    MapColor mapColor = state.getMapColor(world, pos);
                    int rgb = mapColor.color;
                    int yNorth = world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z - 1) - 1;
                    float shade = y > yNorth ? 1.15f : (y < yNorth ? 0.8f : 1.0f);
                    int r = MathHelper.clamp((int) (((rgb >> 16) & 255) * shade), 0, 255);
                    int g = MathHelper.clamp((int) (((rgb >> 8) & 255) * shade), 0, 255);
                    int b = MathHelper.clamp((int) ((rgb & 255) * shade), 0, 255);
                    abgr = 0xFF000000 | (b << 16) | (g << 8) | r;
                }
                img.setColor(dx, dz, abgr);
            }
        }
        mapTexture.upload();
    }

    // ------------------------------------------------------------------ compass

    private static void drawCompass(DrawContext ctx, TextRenderer tr, ClientPlayerEntity player, int w, int h) {
        float bearing = MathHelper.wrapDegrees(player.getYaw() + 180f); // 0 = north
        int half = 65;
        int cx = w - 14 - half;
        int y = h - 12;

        ctx.fill(cx - half, y - 3, cx + half, y - 2, 0x66FFFFFF);
        for (int i = 0; i < DIRS.length; i++) {
            float d = MathHelper.wrapDegrees(i * 45f - bearing);
            if (Math.abs(d) > 52f) continue;
            int x = cx + (int) (d * 1.2f);
            int color = i == 0 ? 0xFFFF5555 : 0xFFFFFFFF;
            ctx.drawCenteredTextWithShadow(tr, DIRS[i], x, y, color);
        }
        ctx.fill(cx, y - 8, cx + 1, y - 3, 0xFFFFD34D);
        int deg = (int) ((bearing + 360f) % 360f);
        ctx.drawCenteredTextWithShadow(tr, String.format("%03d", deg), cx, y - 18, 0xFFCCCCCC);
    }

    // ------------------------------------------------------------------ ammo

    private static void drawAmmo(DrawContext ctx, MinecraftClient mc, TextRenderer tr, ClientPlayerEntity player,
                                 ItemStack held, GunItem gun, int w, int h) {
        int ammo = held.getOrDefault(MwComponents.AMMO, 0);
        boolean creative = player.isCreative();
        String magStr = String.valueOf(ammo);
        String resStr = creative ? "\u221E" : String.valueOf(GunItem.countAmmo(player, gun.ammoItem));

        float bigS = 2.5f;
        float smallS = 1.4f;
        int right = w - 14;
        int yBig = h - 52;
        int wRes = (int) (tr.getWidth(resStr) * smallS);
        int wMag = (int) (tr.getWidth(magStr) * bigS);

        drawScaled(ctx, tr, resStr, right - wRes, yBig + (int) (8 * bigS - 8 * smallS), smallS, 0xFFAAAAAA);
        drawScaled(ctx, tr, magStr, right - wRes - 8 - wMag, yBig, bigS, ammo == 0 ? 0xFFFF5555 : 0xFFFFFFFF);

        // segmented magazine bar
        int segs = Math.min(gun.stats.magazine, 30);
        int filled = gun.stats.magazine <= 0 ? 0 : Math.round(segs * (ammo / (float) gun.stats.magazine));
        int barRight = right - wRes - 8 - wMag - 10;
        int barLeft = barRight - segs * 3;
        for (int i = 0; i < segs; i++) {
            int bx = barLeft + i * 3;
            ctx.fill(bx, yBig + 4, bx + 2, yBig + 18, i < filled ? 0xFFFFFFFF : 0x44FFFFFF);
        }

        Text name = held.getName();
        ctx.drawText(tr, name, right - tr.getWidth(name), h - 29, 0xFFDDDDDD, true);

        // reload progress
        int end = held.getOrDefault(MwComponents.RELOAD_END, 0);
        int now = (int) mc.world.getTime();
        if (end > now) {
            float progress = 1f - (end - now) / (float) Math.max(1, gun.stats.reloadTicks);
            int cx = w / 2;
            int cy = h / 2 + 22;
            ctx.drawCenteredTextWithShadow(tr, Text.translatable("hud.mw2mod.reloading"), cx, cy - 12, 0xFFFFD34D);
            ctx.fill(cx - 30, cy, cx + 30, cy + 3, 0x88000000);
            ctx.fill(cx - 30, cy, cx - 30 + (int) (60 * MathHelper.clamp(progress, 0f, 1f)), cy + 3, 0xFFFFFFFF);
        }
    }

    private static void drawScaled(DrawContext ctx, TextRenderer tr, String text, int x, int y, float scale, int color) {
        ctx.getMatrices().push();
        ctx.getMatrices().translate((float) x, (float) y, 0f);
        ctx.getMatrices().scale(scale, scale, 1f);
        ctx.drawText(tr, text, 0, 0, color, true);
        ctx.getMatrices().pop();
    }

    // ------------------------------------------------------------------ grenades

    private static void drawGrenades(DrawContext ctx, TextRenderer tr, ClientPlayerEntity player, int w, int h) {
        Item[] nades = {MwItems.FRAG_GRENADE, MwItems.FLASHBANG, MwItems.SMOKE_GRENADE, MwItems.INCENDIARY_GRENADE};
        int x = w - 14 - 28;
        int y = h - 78;
        for (int i = nades.length - 1; i >= 0; i--) {
            int count = GunItem.countAmmo(player, nades[i]);
            if (count <= 0) continue;
            ctx.drawItem(new ItemStack(nades[i]), x, y);
            ctx.drawText(tr, "x" + count, x + 17, y + 8, 0xFFFFFFFF, true);
            x -= 40;
        }
    }

    // ------------------------------------------------------------------ crosshair + scope

    private static void drawCrosshair(DrawContext ctx, MinecraftClient mc, GunItem gun, int w, int h) {
        if (gun.stats.scoped && ClientState.zoomCur > 0.85f) return; // the scope has its own reticle
        int cx = w / 2;
        int cy = h / 2;

        boolean moving = mc.player.getVelocity().horizontalLengthSquared() > 0.003;
        float gap = 3f + gun.stats.spread * 0.9f + ClientState.kick * 6f;
        if (moving) gap += 3f;
        if (mc.player.isSprinting()) gap += 3f;
        if (ClientState.zoomCur > 0.5f) gap *= 0.5f;
        int g = Math.round(gap);
        int len = 5;

        tick(ctx, cx, cy - g - len, cx + 1, cy - g);   // top
        tick(ctx, cx, cy + g, cx + 1, cy + g + len);   // bottom
        tick(ctx, cx - g - len, cy, cx - g, cy + 1);   // left
        tick(ctx, cx + g, cy, cx + g + len, cy + 1);   // right
    }

    private static void tick(DrawContext ctx, int x1, int y1, int x2, int y2) {
        ctx.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0x88000000);
        ctx.fill(x1, y1, x2, y2, 0xFFFFFFFF);
    }

    private static void drawScope(DrawContext ctx, GunItem gun, int w, int h) {
        if (!gun.stats.scoped || ClientState.zoomCur < 0.85f) return;
        int cx = w / 2;
        int cy = h / 2;
        int r = (int) (Math.min(w, h) * 0.47f);
        int black = 0xFF000000;

        ctx.fill(0, 0, w, cy - r, black);
        ctx.fill(0, cy + r, w, h, black);
        for (int y = cy - r; y < cy + r; y++) {
            int dy = y - cy;
            int half = (int) Math.sqrt((double) (r * r - dy * dy));
            ctx.fill(0, y, cx - half, y + 1, black);
            ctx.fill(cx + half, y, w, y + 1, black);
        }
        ctx.fill(cx - r, cy, cx + r, cy + 1, black);
        ctx.fill(cx, cy - r, cx + 1, cy + r, black);
    }

    private GunHud() {
    }
}
