package com.mw2mod;

import com.mw2mod.item.GunItem;
import com.mw2mod.net.ReloadPayload;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;

public final class MwNetworking {
    public static void init() {
        PayloadTypeRegistry.playC2S().register(ReloadPayload.ID, ReloadPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ReloadPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            ItemStack stack = player.getMainHandStack();
            if (stack.getItem() instanceof GunItem gun) {
                gun.startReload(player.getWorld(), player, stack);
            }
        });
    }

    private MwNetworking() {
    }
}
