package com.mw2mod.net;

import com.mw2mod.Mw2Mod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;

/** Sent from the client to the server when the reload key (R) is pressed. */
public record ReloadPayload() implements CustomPayload {
    public static final CustomPayload.Id<ReloadPayload> ID = new CustomPayload.Id<>(Mw2Mod.id("reload"));
    public static final PacketCodec<RegistryByteBuf, ReloadPayload> CODEC = PacketCodec.unit(new ReloadPayload());

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
