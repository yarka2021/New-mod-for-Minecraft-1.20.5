package com.mw2mod;

import com.mojang.serialization.Codec;
import net.minecraft.component.ComponentType;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

/** Custom item data: bullets in the magazine and the tick when a reload finishes. */
public final class MwComponents {
    public static final ComponentType<Integer> AMMO = register("ammo");
    public static final ComponentType<Integer> RELOAD_END = register("reload_end");

    private static ComponentType<Integer> register(String name) {
        return Registry.register(Registries.DATA_COMPONENT_TYPE, Mw2Mod.id(name),
                ComponentType.<Integer>builder().codec(Codec.INT).packetCodec(PacketCodecs.VAR_INT).build());
    }

    public static void init() {
    }

    private MwComponents() {
    }
}
