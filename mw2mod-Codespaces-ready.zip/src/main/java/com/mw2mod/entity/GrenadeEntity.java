package com.mw2mod.entity;

import com.mw2mod.MwEntities;
import com.mw2mod.MwItems;
import net.minecraft.block.AbstractFireBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/** One entity for every grenade type (frag, flashbang, smoke, incendiary, 40mm launcher round). */
public class GrenadeEntity extends ThrownItemEntity {
    public enum Kind { FRAG, FLASH, SMOKE, INCENDIARY }

    private Kind kind = Kind.FRAG;
    private int fuse = 40;
    private boolean impact = false;
    private boolean hitSomething = false;
    private int smokeTicks = -1;

    public GrenadeEntity(EntityType<? extends GrenadeEntity> type, World world) {
        super(type, world);
    }

    public GrenadeEntity(World world, LivingEntity owner) {
        super(MwEntities.GRENADE, owner, world);
    }

    public void configure(Kind kind, int fuse, boolean impact) {
        this.kind = kind;
        this.fuse = fuse;
        this.impact = impact;
    }

    @Override
    protected Item getDefaultItem() {
        return MwItems.FRAG_GRENADE;
    }

    // ------------------------------------------------------------ flight

    @Override
    protected void onBlockHit(BlockHitResult hit) {
        super.onBlockHit(hit);
        if (impact) {
            hitSomething = true;
            return;
        }
        Vec3d v = getVelocity();
        switch (hit.getSide().getAxis()) {
            case X -> v = new Vec3d(-v.x * 0.5, v.y, v.z);
            case Y -> v = new Vec3d(v.x * 0.6, Math.abs(v.y) < 0.08 ? 0.0 : -v.y * 0.4, v.z * 0.6);
            case Z -> v = new Vec3d(v.x, v.y, -v.z * 0.5);
        }
        setVelocity(v);
        if (v.lengthSquared() > 0.05 && !getWorld().isClient) {
            getWorld().playSound(null, getX(), getY(), getZ(),
                    SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.PLAYERS, 0.15f, 2.0f);
        }
    }

    @Override
    protected void onEntityHit(EntityHitResult hit) {
        super.onEntityHit(hit);
        if (impact) hitSomething = true;
    }

    @Override
    public void tick() {
        super.tick();
        if (!(getWorld() instanceof ServerWorld sw) || isRemoved()) return;

        if (smokeTicks >= 0) { // smoke grenade already popped: keep spewing
            smokeTicks++;
            if (smokeTicks % 3 == 0) {
                sw.spawnParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, getX(), getY() + 0.4, getZ(),
                        5, 1.8, 0.7, 1.8, 0.01);
            }
            if (smokeTicks > 200) discard();
            return;
        }

        if (hitSomething || --fuse <= 0) {
            detonate(sw);
        }
    }

    // ------------------------------------------------------------ explosions

    private void detonate(ServerWorld sw) {
        switch (kind) {
            case FRAG -> {
                // World.ExplosionSourceType.NONE = damages entities, does NOT break blocks
                sw.createExplosion(this, getX(), getY(), getZ(), 3.2f, World.ExplosionSourceType.NONE);
                discard();
            }
            case FLASH -> {
                flash(sw);
                discard();
            }
            case INCENDIARY -> {
                burn(sw);
                discard();
            }
            case SMOKE -> {
                sw.playSound(null, getX(), getY(), getZ(),
                        SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.PLAYERS, 1.0f, 0.7f);
                smokeTicks = 0;
            }
        }
    }

    private void flash(ServerWorld sw) {
        sw.spawnParticles(ParticleTypes.FLASH, getX(), getY() + 0.3, getZ(), 1, 0, 0, 0, 0);
        sw.playSound(null, getX(), getY(), getZ(),
                SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 2.0f, 2.0f);
        Vec3d pos = getPos().add(0, 0.2, 0);
        Box area = getBoundingBox().expand(16.0);
        for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, area, LivingEntity::isAlive)) {
            Vec3d eye = e.getEyePos();
            Vec3d to = pos.subtract(eye);
            double dist = to.length();
            if (dist > 16.0 || dist < 0.001) continue;
            // walls block the flash
            if (sw.raycast(new RaycastContext(pos, eye, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, this)).getType() != HitResult.Type.MISS) continue;
            double facing = e.getRotationVec(1.0f).dotProduct(to.normalize());
            int ticks = facing > 0.2 ? (int) (170 - dist * 5) : 50; // looking at it = blinded longer
            ticks = Math.max(40, ticks);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, ticks, 0));
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, ticks / 2, 1));
        }
    }

    private void burn(ServerWorld sw) {
        sw.playSound(null, getX(), getY(), getZ(),
                SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.5f, 0.8f);
        sw.spawnParticles(ParticleTypes.FLAME, getX(), getY() + 0.3, getZ(), 60, 1.5, 0.4, 1.5, 0.05);
        BlockPos origin = getBlockPos();
        for (int i = 0; i < 28; i++) {
            BlockPos p = origin.add(random.nextInt(7) - 3, random.nextInt(3) - 1, random.nextInt(7) - 3);
            BlockPos below = p.down();
            if (sw.getBlockState(p).isAir() && sw.getBlockState(below).isSideSolidFullSquare(sw, below, Direction.UP)) {
                sw.setBlockState(p, AbstractFireBlock.getState(sw, p));
            }
        }
        for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(4.0), LivingEntity::isAlive)) {
            e.setOnFireFor(6);
        }
    }

    // ------------------------------------------------------------ save / load

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Kind", kind.ordinal());
        nbt.putInt("Fuse", fuse);
        nbt.putBoolean("Impact", impact);
        nbt.putInt("Smoke", smokeTicks);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        Kind[] kinds = Kind.values();
        kind = kinds[Math.max(0, Math.min(kinds.length - 1, nbt.getInt("Kind")))];
        fuse = nbt.getInt("Fuse");
        impact = nbt.getBoolean("Impact");
        smokeTicks = nbt.contains("Smoke") ? nbt.getInt("Smoke") : -1;
    }
}
