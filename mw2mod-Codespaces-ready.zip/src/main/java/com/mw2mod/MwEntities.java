package com.mw2mod;

import com.mw2mod.entity.GrenadeEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class MwEntities {
    public static final EntityType<GrenadeEntity> GRENADE = Registry.register(Registries.ENTITY_TYPE, Mw2Mod.id("grenade"),
            FabricEntityTypeBuilder.<GrenadeEntity>create(SpawnGroup.MISC, GrenadeEntity::new)
                    .dimensions(EntityDimensions.fixed(0.25f, 0.25f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(10)
                    .build());

    public static void init() {
    }

    private MwEntities() {
    }
}
