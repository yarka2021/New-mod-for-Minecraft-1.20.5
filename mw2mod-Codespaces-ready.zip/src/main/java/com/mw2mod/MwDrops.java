package com.mw2mod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/** Hostile mobs killed by a player sometimes drop ammo and (rarely) grenades. */
public final class MwDrops {
    public static void init() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity.getWorld().isClient) return;
            if (!(entity instanceof HostileEntity)) return;
            if (!(source.getAttacker() instanceof PlayerEntity)) return;

            var rnd = entity.getRandom();
            if (rnd.nextFloat() < 0.35f) {
                Item[] ammo = {
                        MwItems.PISTOL_AMMO, MwItems.RIFLE_AMMO, MwItems.RIFLE_AMMO,
                        MwItems.SHOTGUN_SHELL, MwItems.SNIPER_AMMO, MwItems.MAGNUM_AMMO
                };
                Item pick = ammo[rnd.nextInt(ammo.length)];
                entity.dropStack(new ItemStack(pick, 4 + rnd.nextInt(9)));
            }
            if (rnd.nextFloat() < 0.06f) {
                Item[] nades = {
                        MwItems.FRAG_GRENADE, MwItems.FLASHBANG, MwItems.SMOKE_GRENADE, MwItems.INCENDIARY_GRENADE
                };
                entity.dropStack(new ItemStack(nades[rnd.nextInt(nades.length)], 1));
            }
        });
    }

    private MwDrops() {
    }
}
