package com.mw2mod.item;

import com.mw2mod.MwComponents;
import com.mw2mod.MwItems;
import com.mw2mod.entity.GrenadeEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.Optional;

public class GunItem extends Item {
    public final GunStats stats;
    public final Item ammoItem;

    public GunItem(Settings settings, GunStats stats, Item ammoItem) {
        super(settings);
        this.stats = stats;
        this.ammoItem = ammoItem;
    }

    // ---------------------------------------------------------------- ammo helpers

    public static int countAmmo(PlayerEntity player, Item ammo) {
        int n = 0;
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(ammo)) n += s.getCount();
        }
        return n;
    }

    private static int takeAmmo(PlayerEntity player, Item ammo, int amount) {
        int taken = 0;
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < inv.size() && taken < amount; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(ammo)) {
                int t = Math.min(s.getCount(), amount - taken);
                s.decrement(t);
                taken += t;
            }
        }
        return taken;
    }

    private static boolean isReloading(ItemStack stack, int now) {
        return stack.getOrDefault(MwComponents.RELOAD_END, 0) > now;
    }

    // ---------------------------------------------------------------- use / fire

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        int now = (int) world.getTime();
        if (isReloading(stack, now)) return TypedActionResult.fail(stack);

        int ammo = stack.getOrDefault(MwComponents.AMMO, 0);
        if (ammo <= 0) {
            startReload(world, user, stack); // empty magazine: auto reload
            return TypedActionResult.fail(stack);
        }
        if (world instanceof ServerWorld serverWorld) {
            fire(serverWorld, user, stack, ammo);
        }
        return TypedActionResult.success(stack);
    }

    private void fire(ServerWorld world, PlayerEntity player, ItemStack stack, int ammo) {
        int shots = Math.min(stats.rounds, ammo);
        for (int i = 0; i < shots; i++) {
            if (stats.launcher) {
                launch(world, player);
            } else {
                for (int p = 0; p < stats.pellets; p++) {
                    shoot(world, player, i == 0 && p == 0);
                }
            }
        }
        stack.set(MwComponents.AMMO, ammo - shots);
        if (stats.cooldown > 0) {
            player.getItemCooldownManager().set(this, stats.cooldown);
        }
        muzzleEffects(world, player);
    }

    private void muzzleEffects(ServerWorld world, PlayerEntity player) {
        Vec3d look = player.getRotationVec(1.0f);
        Vec3d m = player.getEyePos().add(look.multiply(1.0)).add(0, -0.15, 0);
        world.spawnParticles(ParticleTypes.SMOKE, m.x, m.y, m.z, 3, 0.03, 0.03, 0.03, 0.01);
        world.spawnParticles(ParticleTypes.FLAME, m.x, m.y, m.z, 1, 0.0, 0.0, 0.0, 0.01);
        float pitch = 1.4f + player.getRandom().nextFloat() * 0.3f;
        if (stats.loud) {
            world.playSound(null, player.getX(), player.getEyeY(), player.getZ(),
                    SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8f, stats.launcher ? 1.5f : 1.9f);
        } else {
            world.playSound(null, player.getX(), player.getEyeY(), player.getZ(),
                    SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, SoundCategory.PLAYERS, 1.0f, pitch);
        }
    }

    /** Hitscan bullet: ray from the eyes, stops at the first wall, damages the first living entity on the way. */
    private void shoot(ServerWorld world, PlayerEntity player, boolean tracer) {
        Random rnd = player.getRandom();
        float spread = stats.spread;
        if (player.isSneaking()) spread *= 0.6f;
        if (player.getVelocity().horizontalLengthSquared() > 0.004) spread *= 1.5f;
        if (!player.isOnGround()) spread *= 2.0f;

        float yaw = player.getYaw() + (rnd.nextFloat() - 0.5f) * 2f * spread;
        float pitch = player.getPitch() + (rnd.nextFloat() - 0.5f) * 2f * spread;
        Vec3d dir = Vec3d.fromPolar(pitch, yaw);
        Vec3d start = player.getEyePos();
        Vec3d end = start.add(dir.multiply(stats.range));

        BlockHitResult blockHit = world.raycast(new RaycastContext(start, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        Vec3d stop = blockHit.getType() == HitResult.Type.MISS ? end : blockHit.getPos();

        Box box = new Box(start, stop).expand(1.0);
        Entity best = null;
        Vec3d bestPos = null;
        double bestDist = start.squaredDistanceTo(stop);
        for (Entity e : world.getOtherEntities(player, box,
                ent -> ent instanceof LivingEntity && ent.isAlive() && !ent.isSpectator())) {
            Optional<Vec3d> hit = e.getBoundingBox().expand(0.15).raycast(start, stop);
            if (hit.isPresent()) {
                double d = start.squaredDistanceTo(hit.get());
                if (d <= bestDist) {
                    bestDist = d;
                    best = e;
                    bestPos = hit.get();
                }
            }
        }

        Vec3d impact = best != null ? bestPos : stop;

        if (best instanceof LivingEntity target) {
            boolean head = bestPos.y >= target.getEyeY() - 0.2;
            float dmg = stats.damage * (head ? stats.headshot : 1.0f);
            target.timeUntilRegen = 0; // allow rapid-fire bullets to all register
            target.damage(world.getDamageSources().playerAttack(player), dmg);
            world.spawnParticles(ParticleTypes.CRIT, bestPos.x, bestPos.y, bestPos.z, 4, 0.1, 0.1, 0.1, 0.1);
            world.playSound(null, player.getX(), player.getEyeY(), player.getZ(),
                    SoundEvents.ENTITY_ARROW_HIT_PLAYER, SoundCategory.PLAYERS, 0.35f, head ? 1.9f : 1.4f);
        } else if (blockHit.getType() != HitResult.Type.MISS) {
            world.spawnParticles(ParticleTypes.SMOKE, impact.x, impact.y, impact.z, 2, 0.05, 0.05, 0.05, 0.01);
        }

        if (tracer) {
            double len = Math.min(start.distanceTo(impact), 60.0);
            for (double d = 2.5; d < len; d += 2.0) {
                Vec3d p = start.add(dir.multiply(d));
                world.spawnParticles(ParticleTypes.CRIT, p.x, p.y - 0.1, p.z, 1, 0, 0, 0, 0);
            }
        }
    }

    private void launch(ServerWorld world, PlayerEntity player) {
        GrenadeEntity g = new GrenadeEntity(world, player);
        g.setItem(new ItemStack(MwItems.GRENADE_40MM));
        g.configure(GrenadeEntity.Kind.FRAG, 100, true); // explodes on impact
        g.setVelocity(player, player.getPitch(), player.getYaw(), 0f, 2.2f, 0.4f);
        world.spawnEntity(g);
    }

    /** Fabric API hook: do not replay the "item swap" animation every time the ammo counter changes. */
    public boolean allowComponentsUpdateAnimation(PlayerEntity player, Hand hand, ItemStack oldStack, ItemStack newStack) {
        return false;
    }

    // ---------------------------------------------------------------- reload

    public void startReload(World world, PlayerEntity player, ItemStack stack) {
        if (world.isClient) return;
        int now = (int) world.getTime();
        if (isReloading(stack, now)) return;
        int ammo = stack.getOrDefault(MwComponents.AMMO, 0);
        if (ammo >= stats.magazine) return;
        if (!player.isCreative() && countAmmo(player, ammoItem) <= 0) {
            player.sendMessage(Text.translatable("message.mw2mod.no_ammo"), true);
            return;
        }
        stack.set(MwComponents.RELOAD_END, now + stats.reloadTicks);
        player.getItemCooldownManager().set(this, stats.reloadTicks);
        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ITEM_CROSSBOW_LOADING_START, SoundCategory.PLAYERS, 0.8f, 1.0f);
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (world.isClient || !(entity instanceof PlayerEntity player)) return;
        int end = stack.getOrDefault(MwComponents.RELOAD_END, 0);
        if (end == 0) return;

        int now = (int) world.getTime();
        if (!selected || end - now > stats.reloadTicks + 40) { // gun put away: cancel reload
            stack.set(MwComponents.RELOAD_END, 0);
            return;
        }
        if (now < end) return;

        int cur = stack.getOrDefault(MwComponents.AMMO, 0);
        int need = stats.magazine - cur;
        int give = player.isCreative() ? need : takeAmmo(player, ammoItem, need);
        stack.set(MwComponents.AMMO, cur + give);
        stack.set(MwComponents.RELOAD_END, 0);
        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ITEM_CROSSBOW_LOADING_END, SoundCategory.PLAYERS, 0.8f, 1.2f);
    }
}
