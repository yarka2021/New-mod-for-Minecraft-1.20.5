package com.mw2mod.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

/** A fast sword that deals big extra damage when hitting an enemy from behind. */
public class KnifeItem extends SwordItem {
    private final float backstabDamage;

    public KnifeItem(ToolMaterial material, Settings settings, float backstabDamage) {
        super(material, settings);
        this.backstabDamage = backstabDamage;
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (!attacker.getWorld().isClient) {
            Vec3d a = attacker.getRotationVec(1.0f);
            Vec3d t = target.getRotationVec(1.0f);
            // both look roughly the same way horizontally -> attacker is behind the target
            if (a.x * t.x + a.z * t.z > 0.5) {
                DamageSource source = attacker instanceof PlayerEntity p
                        ? attacker.getDamageSources().playerAttack(p)
                        : attacker.getDamageSources().mobAttack(attacker);
                target.timeUntilRegen = 0;
                target.damage(source, backstabDamage);
                attacker.getWorld().playSound(null, target.getX(), target.getY(), target.getZ(),
                        SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, SoundCategory.PLAYERS, 1.0f, 1.2f);
            }
        }
        return super.postHit(stack, target, attacker);
    }
}
