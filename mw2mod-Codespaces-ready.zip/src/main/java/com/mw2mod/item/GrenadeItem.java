package com.mw2mod.item;

import com.mw2mod.entity.GrenadeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class GrenadeItem extends Item {
    private final GrenadeEntity.Kind kind;
    private final int fuseTicks;

    public GrenadeItem(Settings settings, GrenadeEntity.Kind kind, int fuseTicks) {
        super(settings);
        this.kind = kind;
        this.fuseTicks = fuseTicks;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        world.playSound(null, user.getX(), user.getY(), user.getZ(),
                SoundEvents.ENTITY_SNOWBALL_THROW, SoundCategory.PLAYERS, 0.6f, 0.8f);
        if (!world.isClient) {
            GrenadeEntity g = new GrenadeEntity(world, user);
            g.setItem(stack.copyWithCount(1));
            g.configure(kind, fuseTicks, false);
            g.setVelocity(user, user.getPitch(), user.getYaw(), 0f, 1.3f, 0.8f);
            world.spawnEntity(g);
        }
        user.getItemCooldownManager().set(this, 20);
        if (!user.getAbilities().creativeMode) {
            stack.decrement(1);
        }
        return TypedActionResult.success(stack, world.isClient());
    }
}
