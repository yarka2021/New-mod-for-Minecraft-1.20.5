package com.mw2mod.item;

/** Tunable numbers for one firearm. Fluent setters keep MwItems readable. */
public final class GunStats {
    public float damage = 4f;       // damage per bullet
    public int rounds = 1;          // bullets fired per trigger pull (2 = fast full-auto feel)
    public int pellets = 1;         // pellets per bullet (shotgun)
    public int cooldown = 0;        // ticks between trigger pulls (0 = hold right click to spray)
    public int magazine = 30;
    public int reloadTicks = 40;
    public float spread = 1.5f;     // degrees of random deviation
    public float range = 80f;       // blocks
    public float recoil = 1f;       // degrees of camera kick per bullet
    public float zoom = 1.15f;      // aim-down-sights zoom factor
    public float headshot = 1.5f;   // headshot damage multiplier
    public boolean scoped = false;  // draws a sniper scope overlay when aiming
    public boolean launcher = false;// fires explosive grenades instead of bullets
    public boolean loud = false;    // heavier gunshot sound

    public GunStats damage(float v) { damage = v; return this; }
    public GunStats rounds(int v) { rounds = v; return this; }
    public GunStats pellets(int v) { pellets = v; return this; }
    public GunStats cooldown(int v) { cooldown = v; return this; }
    public GunStats magazine(int v) { magazine = v; return this; }
    public GunStats reloadTicks(int v) { reloadTicks = v; return this; }
    public GunStats spread(float v) { spread = v; return this; }
    public GunStats range(float v) { range = v; return this; }
    public GunStats recoil(float v) { recoil = v; return this; }
    public GunStats zoom(float v) { zoom = v; return this; }
    public GunStats headshot(float v) { headshot = v; return this; }
    public GunStats scoped() { scoped = true; return this; }
    public GunStats launcher() { launcher = true; return this; }
    public GunStats loud() { loud = true; return this; }
}
