#!/usr/bin/env bash
set -e
./gradlew clean build
printf '\nBuild complete. JAR files:\n'
ls -lh build/libs/*.jar
